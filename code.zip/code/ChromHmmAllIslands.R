source("code/util/GeneralUtilities.R")
source("code/util/ChromHmmUtilities.R")
require("doParallel")
require("foreach")
require("doMC")
require("ggplot2")
require("ggpubr")
registerDoMC(cores = 8)



# Description:
# Given the states data, this procedure combines contiguous states into islands.
getIslands <- function(keys, chr) {
  temp.keys <- keys
  island.id <- numeric(length = length(keys))
  i <- 1
  count <- 1
  while(i < length(keys)) {
    j <- keys == keys[i]
    k <- min(which(j == F))-1
    if(is.infinite(k)) {
      k <- length(keys)
    }
    
    island.id[i:k] <- count
    keys[i:k] <- NA
    count <- count + 1
    i <- k + 1
    # cat(i, "\n")
  }
  
  return (data.frame(chr = chr, 
                     island.id = island.id,
                     keys = temp.keys,
                     stringsAsFactors = F))
}


# states data
# state.data <- get(load(file = "output/states.15.RData"))
state.data <- get(load(file = "output/states.LB.15.RData"))

chrs <- unique(state.data$chr)
keys <- colnames(state.data)[4:15]
for(key in keys) {
  islands <- (foreach(i = 1:length(chrs)) %dopar% getIslands(
    keys = state.data[state.data$chr == chrs[i], key], chr = chrs[i]))
  islands <- do.call(rbind, islands)
  state.data[, paste("island", key, sep = '.')] <- paste(state.data$chr, islands$island.id, sep = '.')
  cat(key, "\n")
}


keys <- colnames(state.data)[which(regexpr(pattern = "island\\.", text = colnames(state.data)) != -1)]
for(key in keys) {
  state.data[, key] <- paste(state.data[, "chr"], state.data[, key], sep = '.')
  cat(key, "\n")
}
# save(state.data, file = "output/chromhmm_islands/states.15.islands.RData")
save(state.data, file = "output/chromhmm_islands/states.LB.15.islands.RData")
rm(islands, key, keys)
