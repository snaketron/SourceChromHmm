source("code/util/GeneralUtilities.R")
source("code/util/ChromHmmUtilities.R")
source("code/util/TadStats.R")
source("code/util/EnhancerUtillities.R")
require("ggplot2")
require("gridExtra")
require("reshape2")
require("tidyr")



getTssPlot <- function(gene.name, tss.spread = 5000) {
  gene.data <- getGenes(dir = "input/genes_biomart/genes.full.txt")
  gene.data <- gene.data[gene.data$Gene.type == "protein_coding", ]
  gene.data <- gene.data[gene.data$Gene.name == gene.name, ]
  
  # PC data
  PC.islands <- get(load(file = "output/chromhmm_islands/PC.islands.15.RData"))
  rm(islands.PC)
  PC.islands <- PC.islands[PC.islands$chr == gene.data$chr & 
                             PC.islands$bp.stop > (gene.data$tss-tss.spread) & 
                             PC.islands$bp.start < (gene.data$tss+tss.spread), ]
  
  # HC data
  HC.islands <- get(load(file = "output/chromhmm_islands/HC.islands.15.RData"))
  rm(islands.HC)
  HC.islands <- HC.islands[HC.islands$chr == gene.data$chr & 
                             HC.islands$bp.stop > (gene.data$tss-tss.spread) & 
                             HC.islands$bp.start < (gene.data$tss+tss.spread), ]
  
  # remove empty states
  PC.islands <- PC.islands[PC.islands$state != "6", ]
  HC.islands <- HC.islands[HC.islands$state != "6", ]
  
  
  # plot
  g <- ggplot()+
    geom_errorbarh(data = gene.data, 
                   aes(y = paste0("G:", Gene.name), xmin = tss-tss.spread, xmax = tss+tss.spread))+
    geom_errorbarh(data = PC.islands, height = 0.2,
                   aes(y = "PC", xmin = bp.start, xmax = bp.stop, col = state))+
    geom_text(data = PC.islands, 
              aes(y = "PC", x = bp.start+(bp.stop-bp.start)/2, label = state), size = 3)+
    geom_errorbarh(data = HC.islands, height = 0.2,
                   aes(y = "HC", xmin = bp.start, xmax = bp.stop, col = state))+
    geom_text(data = HC.islands,
              aes(y = "HC", x = bp.start+(bp.stop-bp.start)/2, label = state), size = 3)+
    geom_point(data = gene.data, 
               aes(y = paste0("G:", Gene.name), x = tss), size = 5, shape = 21, fill = "white")+
    geom_text(data = gene.data, 
              aes(y = paste0("G:", Gene.name), x = tss, label = Strand), size = 3)+
    theme(legend.position = "top")+
    ylab(label = '')+
    xlab(label = "Bp")+
    theme_bw()
  
  return(g)
}



getGenePlot <- function(gene.name, gene.spread = 5000) {
  gene.data <- getGenes(dir = "input/genes_biomart/genes.full.txt")
  gene.data <- gene.data[gene.data$Gene.type == "protein_coding", ]
  gene.data <- gene.data[gene.data$Gene.name == gene.name, ]
  
  # PC data
  PC.islands <- get(load(file = "output/chromhmm_islands/PC.islands.15.RData"))
  rm(islands.PC)
  PC.islands <- PC.islands[PC.islands$chr == gene.data$chr & 
                             PC.islands$bp.stop > (gene.data$bp.start-gene.spread) & 
                             PC.islands$bp.start < (gene.data$bp.stop+gene.spread), ]
  
  # HC data
  HC.islands <- get(load(file = "output/chromhmm_islands/HC.islands.15.RData"))
  rm(islands.HC)
  HC.islands <- HC.islands[HC.islands$chr == gene.data$chr & 
                             HC.islands$bp.stop > (gene.data$bp.start-gene.spread) & 
                             HC.islands$bp.start < (gene.data$bp.stop+gene.spread), ]
  
  # remove empty states
  PC.islands <- PC.islands[PC.islands$state != "6", ]
  HC.islands <- HC.islands[HC.islands$state != "6", ]
  
  
  # plot
  g <- ggplot()+
    geom_errorbarh(data = gene.data, 
                   aes(y = paste0("G:", Gene.name), 
                       xmin = bp.start-gene.spread, 
                       xmax = bp.stop+gene.spread))+
    geom_errorbarh(data = PC.islands, height = 0.2,
                   aes(y = "PC", xmin = bp.start, xmax = bp.stop, col = state))+
    geom_text(data = PC.islands, 
              aes(y = "PC", x = bp.start+(bp.stop-bp.start)/2, label = state), size = 3)+
    geom_errorbarh(data = HC.islands, height = 0.2,
                   aes(y = "HC", xmin = bp.start, xmax = bp.stop, col = state))+
    geom_text(data = HC.islands,
              aes(y = "HC", x = bp.start+(bp.stop-bp.start)/2, label = state), size = 3)+
    geom_point(data = gene.data, 
               aes(y = paste0("G:", Gene.name), x = tss), size = 5, shape = 21, fill = "white")+
    geom_text(data = gene.data, 
              aes(y = paste0("G:", Gene.name), x = tss, label = Strand), size = 3)+
    theme(legend.position = "top")+
    ylab(label = '')+
    xlab(label = "Bp")+
    theme_bw()
  
  return(g)
}




# tss
tss <- getTssPlot(gene.name = "Gli3", tss.spread = 5000) 
tss


# exon
exon <- getGenePlot(gene.name = "Gli3", gene.spread = 5000) 
exon
