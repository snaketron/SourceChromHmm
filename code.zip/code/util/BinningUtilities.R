






getSliding <- function(bam.files, datasets, bin.width, bin.slide, 
                       chrs, minq = 25, fragment.lengths, cores = 1) {
  registerDoMC(cores = cores)
  out <- (foreach(c = 1:length(chrs)) %dopar% windowCounts(bam.files = bam.files, 
                                                           bin = F, 
                                                           width = bin.width, 
                                                           spacing = bin.slide, 
                                                           filter = 0, 
                                                           ext = list(c(fragment.lengths), NA),
                                                           param = readParam(restrict = chrs[c], 
                                                                             minq = minq)))
  
  names(out) <- chrs
  for(chr in chrs) {
    rownames(out[[chr]]) <- out[[chr]]@rowRanges@ranges@start
    colnames(out[[chr]]) <- datasets
    out[[chr]] <- assay(out[[chr]])
  }
  return (out)
}




# Description:
# It takes as input a set of bam.files and creates bins (with csaw) at identical
# genomic regions containing the count of reads in these reads.
getCounting <- function(bam.files, datasets, bin.width, chrs, 
                        minq = 25, fragment.lengths, cores = 1) {
  registerDoMC(cores = cores)
  out <- (foreach(c = 1:length(chrs)) %dopar% windowCounts(bam.files = bam.files, 
                                                           bin = T, 
                                                           width = bin.width, 
                                                           spacing = bin.slide, 
                                                           filter = 0, 
                                                           ext = list(c(fragment.lengths), NA),
                                                           param = readParam(restrict = chrs[c], 
                                                                             minq = minq)))
  
  names(out) <- chrs
  for(chr in chrs) {
    rownames(out[[chr]]) <- out[[chr]]@rowRanges@ranges@start
    colnames(out[[chr]]) <- datasets
    out[[chr]] <- assay(out[[chr]])
    min.i <- min(which(apply(X = out[[chr]], MARGIN = 1, FUN = sum) != 0)) - 1
    out[[chr]] <- out[[chr]][-(1:min.i), ]
  }
  return (out)
}




# Description:
# Uses tool NucHunter to estimate mean/variance of real and phantop fragment lengths
# Hint: can take a long time (hours) to process all datasets.
getFragmentLengths <- function(data.map) {
  data.map$mu.fragment.length <- NA
  data.map$var.fragment.length <- NA
  data.map$mu.phantom.length <- NA
  data.map$var.phantom.length <- NA
  
  for(i in 1:nrow(data.map)) {
    dir <- data.map$bam[i]
    
    cmd <- paste("java -jar /home/nfs_data/exome_project/ChromHMM/dist/NucHunter.jar fraglen -in ", dir, sep = '')
    system(command = cmd)
    
    out <- read.csv(file = "fragmentLengthInference.txt", stringsAsFactors = F)
    
    mu.frag <- unlist(strsplit(x = out[2, ], split = '\t'))[1]
    mu.frag <- as.numeric(gsub(pattern = "mu:", replacement = '', x = mu.frag))
    data.map$mu.fragment.length[i] <- mu.frag
    
    v.frag <- unlist(strsplit(x = out[2, ], split = '\t'))[2]
    v.frag <- as.numeric(gsub(pattern = "sigma\\^2: ", replacement = '', x = v.frag))
    data.map$var.fragment.length[i] <- v.frag
    
    mu.phantom <- unlist(strsplit(x = out[4, ], split = '\t'))[1]
    mu.phantom <- as.numeric(gsub(pattern = "mu:", replacement = '', x = mu.phantom))
    data.map$mu.phantom.length[i] <- mu.phantom
    
    v.phantom <- unlist(strsplit(x = out[4, ], split = '\t'))[2]
    v.phantom <- as.numeric(gsub(pattern = "sigma\\^2: ", replacement = '', x = v.phantom))
    data.map$var.phantom.length[i] <- v.phantom
  }
  
  save(data.map, file = "data.map.RData")
  return (data.map)
}





# creating the data.map file
data.map <- read.csv(file = "output/files.csv", header = T, sep = ',', stringsAsFactors = F)
data.map <- data.map[!is.na(data.map$ok), ]
data.map <- data.map[data.map$ok == 1, ]
data.map$membership.key <- paste(data.map$state, data.map$mark, sep = '.')
data.map$membership <- as.numeric(as.factor(data.map$membership.key))
data.map <- data.map[order(data.map$membership, decreasing = F), ]
data.map$id <- 1:nrow(data.map)
data.map$membership.key <- NULL
data.map$bam <- paste("/home/nfs_data/exome_project/re-processing_anja/", data.map$bam, sep = '')
data.map$bai <- paste("/home/nfs_data/exome_project/re-processing_anja/", data.map$bai, sep = '')



# computing the fragment lengths (can take a lot of time), not really used here fragment length = 180bp
dm <- getFragmentLengths(data.map = data.map)



# compute sliding window based matrix of counts
# window = 200, slide = 100
source("code/GeneralUtilities.R")
require(chipseq)
library(rtracklayer)
library(IRanges)
library(GenomicRanges)
library(spp)
library(snow)
library(doMC)
library(csaw)


load("output/data.map.RData")
data.map <- data.map[data.map$ok == 1, ]
data.map <- data.map[data.map$mark %in% c("Igg", "H3K27ac"), ]
datasets <- paste(data.map$state, data.map$mark, data.map$id, sep = ".")
chrs <- c(paste("chr", 1:19, sep = ''), "chrX", "chrY")

# set fragment length to 180 (fixed for all datasets)
data.map$fl <- 180 

sliding.data <- getSliding(bam.files = data.map$bam, 
                           datasets = datasets,
                           bin.width = 200, 
                           bin.slide = 100, 
                           chrs = chrs,
                           minq = 25, 
                           fragment.lengths = data.map$fl,
                           cores = 20)

# collect bin data
bin.data <- c()
for(i in 1:length(sliding.data)) {
  bin <- data.frame(sliding.data[[i]], stringsAsFactors = F)
  bin$chr <- names(sliding.data)[i]
  bin$bp <- rownames(bin)
  bin.data <- rbind(bin.data, bin)
  cat(i, ",")
}
save(bin.data, file = "output/sliding.H3K27ac.Igg.RData")




